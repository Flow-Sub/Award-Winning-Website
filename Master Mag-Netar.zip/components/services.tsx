"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Figma, Globe, Smartphone, Zap, Database, ShoppingCart, MessageCircle, Brain, ArrowUpRight } from "lucide-react"

const services = [
  {
    icon: Figma,
    title: "Figma Design",
    description: "Professional UI/UX design with pixel-perfect precision and user-centered approach.",
    number: "01",
    image: "/modern-figma-design-interface-with-ui-components-a.png",
  },
  {
    icon: Globe,
    title: "Website Development",
    description: "Top-notch web applications built with modern technologies and best practices.",
    number: "02",
    image: "/modern-website-development-code-editor-with-react-.png",
  },
  {
    icon: Smartphone,
    title: "App Development",
    description: "Native and cross-platform mobile applications that deliver exceptional user experiences.",
    number: "03",
    image: "/mobile-app-development-interface-with-react-native.png",
  },
  {
    icon: Zap,
    title: "Automation",
    description: "Streamline your workflows with intelligent automation solutions and integrations.",
    number: "04",
    image: "/workflow-automation-dashboard-with-connected-proce.png",
  },
  {
    icon: Database,
    title: "Data Scraping",
    description: "Extract valuable insights from web data with our advanced scraping technologies.",
    number: "05",
    image: "/data-scraping-visualization-with-web-crawlers-and-.png",
  },
  {
    icon: ShoppingCart,
    title: "Shopify Solutions",
    description: "Complete e-commerce development and management for your Shopify store.",
    number: "06",
    image: "/shopify-store-dashboard-with-ecommerce-analytics-a.png",
  },
  {
    icon: MessageCircle,
    title: "Chatbot Development",
    description: "Intelligent conversational interfaces that enhance customer engagement.",
    number: "07",
    image: "/ai-chatbot-interface-with-conversation-flow-and-na.png",
  },
  {
    icon: Brain,
    title: "AI Agents",
    description: "Custom AI-powered agents that automate complex tasks and decision-making processes.",
    number: "08",
    image: "/ai-agent-dashboard-with-machine-learning-models-an.png",
  },
]

export function Services() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll(
              ".scroll-reveal, .scroll-reveal-left, .scroll-reveal-right, .scroll-reveal-scale",
            )
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add("revealed")
              }, index * 100)
            })
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="services" ref={sectionRef} className="py-32 bg-black text-white relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-20 right-20 w-px h-32 bg-white/10"></div>
      <div className="absolute bottom-40 left-20 w-px h-24 bg-white/10"></div>

      <div className="max-w-7xl mx-auto px-8 md:px-16 lg:px-24">
        {/* Header */}
        <div className="mb-24 scroll-reveal">
          <div className="flex justify-between items-start mb-12">
            <div>
              <p className="font-mono text-sm tracking-wider text-white/60 mb-4 uppercase">What We Do</p>
              <h2 className="font-serif text-6xl md:text-8xl font-light leading-tight">Services</h2>
            </div>
            <div className="text-right max-w-md">
              <p className="font-mono text-sm text-white/80 leading-relaxed">
                We craft digital experiences that push boundaries and deliver exceptional results for forward-thinking
                brands.
              </p>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="space-y-px bg-white/5">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`group bg-black hover:bg-white/5 transition-all duration-500 cursor-pointer scroll-reveal-scale relative overflow-hidden`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-center justify-between p-8 md:p-12 border-b border-white/10 last:border-b-0 relative">
                <div className="flex items-center gap-8 flex-1">
                  <div className="font-mono text-sm text-white/40 w-8">{service.number}</div>

                  <div className="flex items-center gap-6">
                    <service.icon className="w-6 h-6 text-white/60 group-hover:text-white transition-colors duration-300" />
                    <div>
                      <h3 className="font-serif text-2xl md:text-3xl font-light mb-2 group-hover:text-white transition-colors duration-300">
                        {service.title}
                      </h3>
                      <p className="text-white/60 max-w-md font-mono text-sm leading-relaxed group-hover:text-white/80 transition-colors duration-300">
                        {service.description}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-500 ease-out">
                    <div className="relative overflow-hidden rounded-lg border border-white/20 bg-white/5 backdrop-blur-sm">
                      <img
                        src={service.image || "/placeholder.svg"}
                        alt={`${service.title} preview`}
                        className="w-48 h-32 object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                  </div>

                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <ArrowUpRight className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-24 text-center scroll-reveal">
          <p className="font-mono text-sm text-white/60 mb-8 tracking-wider uppercase">Ready to Start Your Project?</p>
          <Button
            size="lg"
            className="bg-white text-black hover:bg-gray-200 font-mono text-sm tracking-wider px-12 py-4 magnetic-hover"
          >
            GET IN TOUCH
            <ArrowUpRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}
