"use client"

import { useEffect, useState } from "react"

const caseStudies = [
  {
    title: "E-commerce Revolution",
    category: "Shopify Development",
    description:
      "Transformed a traditional retail business into a thriving online marketplace with 300% increase in sales.",
    image: "/modern-ecommerce-dashboard.png",
    tags: ["Shopify", "React", "Analytics"],
    color: "from-purple-500 to-pink-500",
    accent: "border-purple-400/30 bg-purple-500/10",
  },
  {
    title: "AI-Powered Analytics",
    category: "AI Agents",
    description:
      "Built intelligent data analysis system that reduced manual reporting time by 80% for enterprise client.",
    image: "/ai-analytics-dashboard.png",
    tags: ["AI", "Machine Learning", "Dashboard"],
    color: "from-blue-500 to-cyan-500",
    accent: "border-blue-400/30 bg-blue-500/10",
  },
  {
    title: "Mobile Banking App",
    category: "App Development",
    description: "Designed and developed secure mobile banking application serving 100K+ active users.",
    image: "/mobile-banking-app.png",
    tags: ["React Native", "Security", "FinTech"],
    color: "from-green-500 to-emerald-500",
    accent: "border-green-400/30 bg-green-500/10",
  },
  {
    title: "Automation Suite",
    category: "Automation",
    description: "Created comprehensive workflow automation that streamlined operations for manufacturing company.",
    image: "/workflow-automation-interface.png",
    tags: ["Automation", "API", "Integration"],
    color: "from-orange-500 to-red-500",
    accent: "border-orange-400/30 bg-orange-500/10",
  },
]

export function CaseStudies() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isHovering, setIsHovering] = useState(false)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    if (isHovering) {
      document.addEventListener("mousemove", handleMouseMove)
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
    }
  }, [isHovering])

  return (
    <>
      {isHovering && (
        <div
          className="fixed pointer-events-none z-50 w-20 h-20 rounded-full border-2 border-white mix-blend-difference transition-all duration-200 ease-out"
          style={{
            left: mousePosition.x - 40,
            top: mousePosition.y - 40,
            backgroundColor: "white",
          }}
        />
      )}

      <section
        id="work"
        className="py-32 bg-black relative overflow-hidden"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-px h-40 bg-gradient-to-b from-purple-500 to-pink-500 rotate-45"></div>
          <div className="absolute top-40 right-32 w-px h-32 bg-gradient-to-b from-blue-500 to-cyan-500 -rotate-45"></div>
          <div className="absolute bottom-40 left-1/3 w-px h-24 bg-gradient-to-b from-green-500 to-emerald-500 rotate-12"></div>
          <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/4 w-1 h-1 bg-pink-500 rounded-full animate-pulse delay-1000"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-24">
            <h2 className="font-mono text-sm tracking-[0.2em] text-white/60 mb-8 uppercase">Selected Work</h2>
            <h3 className="font-serif text-6xl md:text-8xl font-light bg-gradient-to-r from-white via-gray-200 to-white bg-clip-text text-transparent mb-8 leading-none">
              CASE STUDIES
            </h3>
            <div className="w-24 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            {caseStudies.map((study, index) => (
              <div key={study.title} className="group cursor-none">
                <div className="aspect-[4/3] overflow-hidden mb-8 bg-white/5 border border-white/10 relative">
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${study.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500`}
                  ></div>
                  <img
                    src={study.image || "/placeholder.svg"}
                    alt={study.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div
                    className={`absolute top-4 right-4 w-3 h-3 ${study.accent} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
                  ></div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span
                      className={`font-mono text-xs tracking-wider bg-gradient-to-r ${study.color} bg-clip-text text-transparent uppercase font-bold`}
                    >
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span className="font-mono text-xs tracking-wider text-white/60 uppercase">{study.category}</span>
                  </div>

                  <h3 className="font-serif text-3xl md:text-4xl font-light text-white group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300">
                    {study.title}
                  </h3>

                  <p className="text-white/70 leading-relaxed text-lg">{study.description}</p>

                  <div className="flex flex-wrap gap-3 pt-4">
                    {study.tags.map((tag, tagIndex) => (
                      <span
                        key={tag}
                        className={`font-mono text-xs tracking-wider text-white/50 border transition-all duration-300 px-3 py-1 group-hover:${study.accent} group-hover:text-white/80`}
                        style={{ transitionDelay: `${tagIndex * 100}ms` }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-32">
            <div className="inline-block relative group cursor-none">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-blue-500 to-green-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-sm"></div>
              <div className="relative border border-white/20 px-8 py-4 bg-black hover:bg-white/5 transition-colors duration-300">
                <span className="font-mono text-sm tracking-wider text-white uppercase">View All Work</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
