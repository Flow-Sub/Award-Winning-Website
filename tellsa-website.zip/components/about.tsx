"use client"

import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

const achievements = [
  "500+ Projects Delivered",
  "98% Client Satisfaction",
  "24/7 Support Available",
  "Award-Winning Team",
]

export function About() {
  return (
    <section id="about" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-6">
              Crafting Digital Excellence Since Day One
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              At TELLSA, we believe in the power of exceptional design and cutting-edge technology. Our team of experts
              combines creativity with technical expertise to deliver solutions that not only meet your needs but exceed
              your expectations.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              {achievements.map((achievement) => (
                <div key={achievement} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                  <span className="text-foreground font-medium">{achievement}</span>
                </div>
              ))}
            </div>

            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Learn More About Us
            </Button>
          </div>

          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-accent/20 to-secondary/20 rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent" />
              <div className="relative z-10 h-full flex items-center justify-center">
                <div className="text-center">
                  <div className="w-32 h-32 bg-accent/20 rounded-full mx-auto mb-6 flex items-center justify-center animate-float">
                    <div className="w-16 h-16 bg-accent rounded-full" />
                  </div>
                  <h3 className="font-serif font-bold text-2xl text-foreground mb-2">Innovation Driven</h3>
                  <p className="text-muted-foreground">Pushing boundaries with every project</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
